<?php
  // Pour libérer le port 80 et activer wamp
  // taper dans le cmd "net stop WAS"
  /*
  ------------------------------------------------------------------------------
  SERVEUR TEST DE LA PARTIE D'ATTENTE DE COUP DE L'ADVERSAIRE
  Ce serveur a pour but de simuler l'attente du coup d'un joueur entre deux
  client.
  N'ayant que la simple vocation de simuler la partie EF-52, les données
  renvoyé aux clients ne respectent pas forcément le format attendu dans
  le projet final.
  -- attention --
  Pour cette phase de tests, les parties 'client' ont été modifiées pour pouvoir
  intéragir avec les données renvoyées par le serveur.
  ------------------------------------------------------------------------------
  */

  $mes;
  $mes2;
  $tralala= 1;
  $abandon=0;
  $partie=1;
  $cote=0;


  function hist($fichier, $tour_jeu, $trait){
    /*
    Fonction permettant de remplir l'historique de la partie stocké dans
    le fichier "historique_blanc" pour les blancs et "historique_noir"
    pour les noirs
    données en entrée: la base de données
                       la cote du joueur devant jouer
                       le trait du joueur
    */


    $histo=fgetss($fichier); //on récupère les données stockées dans l'historique
    $tralala=1;
    if ($histo=='') {
      //Si l'historique est vide,
      //on creer un tableau vide pour stocker les nouveaux coups
      $histo1 = [];
    }
    else{
    $histo1=[$histo];}
    if ($tour_jeu==1) {
      //on récupère les données envoyées par les blancs grâce à un "get"
      $mes=$_GET["donnees"];
      if ($trait==1){
        //dans l'historique des blancs, on va écrire la variable "coups"
      $coups = '{"je_joue":"'.$mes.'","vue":'.$tralala.'}';}
      elseif ($trait==2){
        //dans l'historique des noirs, on va écrire la variable "coups"
        $coups = '{"il_joue":"'.$mes.'","vue":'.$tralala.'}';
      }}
    if ($tour_jeu==2){
      //c'est aux noirs de jouer
      //on récupère les données envoyées par les noirs grâce à un "get"
      $mes2=$_GET["donnees2"];
      if ($trait==1){
        //dans l'historique des noirs, on va écrire la variable "coups"
        $coups = '{"il_joue":"'.$mes2.'","vue":'.$tralala.'}';
      }
      elseif ($trait==2) {
        //dans l'historique des blancs, on va écrire la variable "coups"
        $coups = '{"je_joue":"'.$mes2.'","vue":'.$tralala.'}';
      }
    }
    $histo1[]=$coups; //à la liste dans laquelle on a stocker l'historique
    // va s'ajouter le message de la dernière action

    //on fait changer la valeur de la cote
    if ($tour_jeu==1){$tour_jeu=2;}
    else if ($tour_jeu==2){$tour_jeu=1;}


    $new_test='{"tour":4,"cote":'.$tour_jeu.',"histo":'.json_encode($histo1).'}';
      fseek($fichier, 0); // On remet le curseur au début du fichier

      //on stocke l'historique sous la forme d'une chaine de caractere pour
      //pouvoir la lire dans la partie client
      for ($i=0; $i<sizeof($histo1);$i++){
        if ($i==0){
          fputs($fichier,$histo1[$i]);
        }else{
          fputs($fichier,'","'.$histo1[$i]);
        }
      }
    return $new_test;}

  // on stocke la "cote" dans un fichier "test.sql"
  $monfichier = fopen('test.sql', 'r+');
  $histo_test = fgetss($monfichier);
  fseek($monfichier, 0); // On remet le curseur au début du fichier


  $cote=$histo_test[0]; //prend la valeur de la cote stocké dans le fichier 'test.sql'


  $fichier_blanc= fopen('historique_blanc.sql', 'r+');
  $fichier_noir= fopen('historique_noir.sql', 'r+');
  if ($cote==1){
    //on test si "$_GET["donnees"]" existe.
    //revoi "true" pour les blancs et "false" pour les noirs
    if (isset($_GET["donnees"])){

      //on test lors de l'appel au serveur par le joueur (les blancs) si les
      //données envoyées sont presentes ou non
      //renvoi "true" si la chaine de caractere envoyée existe
      //       "false" si l'input du html est vide lors de l'appel au serveur
      if ($_GET["donnees"]!='' && $_GET["donnees"]!=' '){

        // on modifie l'historique des blancs et des noirs
        $test_blanc=hist($fichier_blanc,$cote,1);
        hist($fichier_noir,$cote,2);

        //on modifie la valeur de la cote
        $cote=2;

      //on renvoi au client (les blancs) son historique
      echo $test_blanc;
    }
      else{
        //cas où le joueur n'a pas joué
        //i.e: on récupère $_GET["donnees"] == ''

        //on récupère l'historique des blancs
        $histo_blanc=fgetss($fichier_blanc);

        if ($histo_blanc=='') {
          //cas où l'historique est vide
          $histo_blanc_2 = [];
        }
        else{
          //historique non-vide, on le renvoi donc au client
          $histo_blanc_2=[$histo_blanc];}
          $new_test='{"tour":4,"cote":'.$cote.',"histo":'.json_encode($histo_blanc_2).'}';
          echo $new_test;
      }
    }
    else{
      //cas où isset($_GET["donnees"]) == false et la "cote " == 1
      $histo_noir=fgetss($fichier_noir);

      if ($histo_noir=='') {
        //cas où l'historique des noirs est vide
        $histo_noir_2 = [];
      }
      else{
        //historique non-vide, on le renvoi donc au client
      $histo_noir_2=[$histo_noir];}
      $new_test='{"tour":4,"cote":'.$cote.',"histo":'.json_encode($histo_noir_2).'}';
      echo $new_test;
    }
  }else{
    if (isset($_GET["donnees2"])){
      if ($_GET["donnees2"]!='' && $_GET["donnees2"]!=' '){
        //on test lors de l'appel au serveur par le joueur (les noirs) si les
        //données envoyées sont presentes ou non
        //renvoi "true" si la chaine de caractere envoyée existe
        //       "false" si l'input du html est vide lors de l'appel au serveur

        $test2=hist($fichier_noir,$cote,2);
        hist($fichier_blanc,$cote,1);
        $cote=1;
        echo $test2;
      }
    else{
      //cas où le joueur n'a pas joué
      //i.e: on récupère $_GET["donnees2"] == ''
      $histo_noir=fgetss($fichier_noir);
      if ($histo_noir=='') {
        //cas où l'historique des noirs est vide
        $histo_noir_2 = [];
      }
      else{
      $histo_noir_2=[$histo_noir];}
      $new_test='{"tour":4,"cote":'.$cote.',"histo":'.json_encode($histo_noir_2).'}';
      //hist($fichier_noir,$cote,2);
      echo $new_test;
    }
  }
    else{
      $histo_blanc=fgetss($fichier_blanc);
      //$cote=1;
      if ($histo_blanc=='') {
        $histo_blanc_2 = [];
      }
      else{
        //historique non-vide, on le renvoi donc au client
      $histo_blanc_2=[$histo_blanc];}
      $new_test='{"tour":4,"cote":'.$cote.',"histo":'.json_encode($histo_blanc_2).'}';
      echo $new_test;
    }
  }
  //on ferme les fichiers des historiques des blancs et des noirs
  fclose($fichier_blanc);
  fclose($fichier_noir);
  //on modifie la valeur de la cote stocké dans notre fichier 'test.sql'
  fputs($monfichier,$cote);
  // on ferme le fichier dans lequel est stocké la cote
  fclose($monfichier);


  /*
    ----------------------------------------------------------------------
      GESTION DE L'ABANDON ET DE LA PARTIE NULLE

      -on a stocké dans le fichier 'etat_partie.sql' la situation des
      blancs et des noirs vis à vis de la partie
      i.e : dans des objets JSON, on stocke sous forme de booléen des
      paramètres tel que l'abandon, la partie nulle et le refus de la partie
      nulle
    ----------------------------------------------------------------------
  */
  $partie = fopen('etat_partie.sql', 'r+'); // on ouvre le fichier
  $etat_partie = fgetss($partie); //on récupère ce qui y est stocké
  if ($etat_partie == '' || $etat_partie == ' '){
    //cas où le fichier 'état_partie.sql' est vide

    //on créer les objets JSON spécifiques au deux joueurs
    $etat_blanc = '{"Joueur_blanc":{"Abandon":"false","Partie_nulle":"false","Refus":"false"}}';
    $etat_noir = '{"Joueur_noir":{"Abandon":"false","Partie_nulle":"false","Refus":"false"}}';

    fseek($partie , 0);
    //on stocke les objets JSON dans le fichier sous la forme:
    //{etat_des_blancs}-{etat_des_noirs}
    fputs($partie,$etat_blanc);
    fputs($partie, '-');
    fputs($partie, $etat_noir);
  }
  fclose($partie);


  if (isset($_GET['Abandon_blanc2'])){
    //on test l'existence d'un des paramètres de l'etat de la partie
    //des blancs dans le cas où les blancs accèdent au serveur

    //on récupère la valeur des booléens des paramètres "abandon", "partie nulle"
    //et "rejet partie nulle"

    echo '--'.$_GET['Abandon_blanc2'];
    echo '--'.$_GET['Proposer_partie_nulle_blanc'];
    echo '--'.$_GET['Rejeter_partie_nulle_blanc'];

    //on stocke l'ensemble de ces paramètres dans l'objet JSON relatif aux blancs
    $etat_blanc = '{"Joueur_blanc":{"Abandon":"'.$_GET['Abandon_blanc2'].'","Partie_nulle":"'.$_GET['Proposer_partie_nulle_blanc'].'","Refus":"'.$_GET['Rejeter_partie_nulle_blanc'].'"}}';

    //on récupère l'etat de la partie pour les noirs et on modifie la partie des blancs
    $partie2 = fopen('etat_partie.sql', 'r+');
    $etat_partie = fgetss($partie2);
    $etat_bn = explode('-', $etat_partie);
    $etat_noir = $etat_bn[1];
    echo '--'.$etat_blanc.'-'.$etat_noir;

    fseek($partie2 , 0);
    fputs($partie2,$etat_blanc);
    fputs($partie2, '-');
    fputs($partie2, $etat_noir);
    fclose($partie2);
  }




  if (isset($_GET['Abandon_noir2'])){
    //on test l'existence d'un des paramètres de l'etat de la partie
    //des noirs dans le cas où les blancs accèdent au serveur

    //on récupère la valeur des booléens des paramètres "abandon", "partie nulle"
    //et "rejet partie nulle"
    echo '--'.$_GET['Abandon_noir2'];
    echo '--'.$_GET['Proposer_partie_nulle_noir'];
    echo '--'.$_GET['Rejeter_partie_nulle_noir'];
    $etat_noir = '{"Joueur_noir":{"Abandon":"'.$_GET['Abandon_noir2'].'","Partie_nulle":"'.$_GET['Proposer_partie_nulle_noir'].'","Refus":"'.$_GET['Rejeter_partie_nulle_noir'].'"}}';

      //on récupère l'etat de la partie pour les noirs et on modifie la partie des blancs
    $partie2 = fopen('etat_partie.sql', 'r+');
    $etat_partie = fgetss($partie2);
    $etat_bn = explode('-', $etat_partie);
    $etat_blanc= $etat_bn[0];
    echo '--'.$etat_blanc.'-'.$etat_noir;
    ftruncate($partie2,0);
    fseek($partie2 , 0);
    fputs($partie2,$etat_blanc);
    fputs($partie2, '-');
    fputs($partie2, $etat_noir);
    fclose($partie2);
  }

?>
