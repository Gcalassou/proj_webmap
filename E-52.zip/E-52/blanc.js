/*
------------------------------------------------------------------
PARTIE CLIENT REPRESANTANT LE CAMP DES BLANCS
Ce code a été développé pour fonctionner avec le serveur de test.
Certaines des fonctions présentes ne fonctionnent qu'avec ce modèle
de serveur en particulier

------------------------------------------------------------------
*/
var num_test=0;// temps entre chaque test automatique
var test_ok=0; //variable permettant de bloquer l'envoi de données quand celui-ci est activé
var historique = "[]"; //variable permettant de stocker l'historique du client
var compteur=0; //variable temporelle
var data;
var cote;

function creerInstance(){
  //Fonction permettant de créer une requête xmlthttp à envoyer par la suite au serveur
  if(window.XMLHttpRequest){
    return new XMLHttpRequest();
  }else if(window.ActiveXObject){
    var names = [
      "Msxml2.XMLHTTP.6.0",
      "Msxml2.XMLHTTP.3.0",
      "Msxml2.XMLHTTP",
      "Microsoft.XMLHTTP"];
    for(var i in names){
      try{ return new ActiveXObject(names[i]); }
      catch(e){}
    }
    alert("Non supporte");
    return null; // non supporté
  }
};
function lecture_histo(historique){
  /*
    Fonction permettant de modifier le format de l'historique renvoyé
    par le serveur pour pouvoir convertir par la suite celui-ci en
    objet JSON
  */
  var re1 = new RegExp('"{', 'gi');
  var re2 = new RegExp('}"', 'gi');

  //remplace l'ensemble des caractères '--{' et '}--'
  //respectivement par '"{' et '}"'
  historique = historique.replace(re1, '--{');
  historique = historique.replace(re2, '}--');
  return historique;
  }


function Abandon_adversaire(abandon_noir, cote){
  /*
  Fonction testant si l'adversaire demande l'abandon de la partie
  */
  if (abandon_noir == 'true' ){
    //Si l'abandon est déclaré, on affiche un message pour afficher
    //notre vistoire
    alert('Vous avez gagné par abandon de votre adversaire!!');

    return true;
    }
  }

function egalite(egalite_noir, egalite_blanc, refus_noir){
  /*
    Fonction permettant de tester si :
      - l'adversaire demande une partie nulle
      - la demande de partie nulle a été acceptée
      - la demande de partie nulle a été rejetée
  */
  if (egalite_noir=='true'){
    //Si l'aversaire demande une partie nulle, la fonction nous renvoi
    //un message pour nous informer de cette demande
    alert("L'adversaire propose une partie nulle!!");
  }
  if (egalite_blanc =='true' && egalite_noir=='true'){
    // Vérifie si les deux joueurs ont acceptés la partie nulle
    //Renvoi un message pour signaler la fin de la partie
    alert('Partie nulle : Fin de la partie!!');
  }
  if (egalite_blanc =='true' && refus_noir=='true'){
    //Cas où  la demande de parite nulle a été rejeté
    // Renvoi un message pour informer le joueur
    alert("L'adversaire a refusé votre demande de finir sur une partie nulle!!");
    document.getElementById('PN').value= 'false';
  }
}

function envoyerDonnees (){
  /*
  Fonction permettant de faire une requête en AJAX au serveur
  Renvoi:
    -- etat de la partie (pion joué, cote, trait,  historique)
  */


  // "req" est égale à XMLHttpRequest si la création de la variable XTML est
  //validé par la fonction "creerInstance"
  var req =  creerInstance();

  var donneeClient =document.getElementById('test').value; //données écritent dans l'input
                                                          //du fichier html
  // var test_check = document.getElementById('Ab').checked;
  // var test_PN = document.getElementById('Pnb').checked;
  var Abb= document.getElementById('Ablanc').value;//récupère la valeur du bouton Abandon
  var pnul =document.getElementById('PN').value;//récupère la valeur du bouton Partie nulle
  var rej_pn = document.getElementById('RPN').value;//récupère la valeur du bouton Rejet
  req.onreadystatechange = function(){
  if(req.readyState == 4){
    if(req.status == 200){
      requete_serveur=req.responseText; // on récupère la réponse du serveur sous format texte
      console.log(requete_serveur);

      //on decoupe la réponse pour la sotcker sous forme de liste de chaine de
      //caracteres
      requete_serveur_modif = requete_serveur.split('--');
      console.log(requete_serveur_modif);

      //on transforme une partie de la chaine de caractere en objet JSON
      objet_json=JSON.parse(requete_serveur_modif[0]);
      //console.log(objet_json.histo[0]);

      //on récupère les valeurs étant attribuées aux paramètres d'Abandon
      // de partie nulle et de rejet de la partie nulle des 2 joueurs
      //le format de stockage est un JSON sous forme de chaine de caractères
      var etat = requete_serveur_modif[4];

      //on sépare le cas des joueurs blanc et noir vis à vis de l'Abandon, la partie nulle et
      //le rejet de celle-ci en les stockants dans un tableau
      var etat2 = etat.split('-');
      console.log(etat);
      console.log(etat2[1]);


      //on converti les valeurs du tableau 'etat2' sous forme d'objets JSON
      etat_noir = JSON.parse(etat2[1]);
      etat_blanc = JSON.parse(etat2[0]);

      //on stocke la cote dans une variable
      cote = objet_json.cote;
      console.log(etat_noir.Joueur_noir.Abandon);

      //On teste si l'adversaire a demandé à abandonner
      Abandon_adversaire(etat_noir.Joueur_noir.Abandon, objet_json.cote);

      //On teste si l'adversaire a demandé une partie nulle
      egalite(etat_noir.Joueur_noir.Partie_nulle,etat_blanc.Joueur_blanc.Partie_nulle, etat_noir.Joueur_noir.Refus);


      if(objet_json.histo[0]!=null){
        //si l'historique renvoyé est non-vide on le découpe et le stocke
        //sous forme de tableau
        console.log('cote'+objet_json.cote);
        console.log((objet_json.histo[0])[0]);

        var objet_json_modif = (lecture_histo(objet_json.histo[0])).split('--,--');

        console.log(objet_json_modif);
      }

      //on lance la fonction de vérification pour déterminer s'il y a eu des changements
      //au niveau de l'historique
      verification(objet_json);


      num_test+=1;
      // console.log("num_test : "+num_test);
      console.log('etat abandon : '+etat_noir.Joueur_noir.Abandon);
      console.log('etat pn blanc : '+etat_blanc.Joueur_blanc.Partie_nulle);
      console.log('etat pn noir : '+etat_noir.Joueur_noir.Partie_nulle);
      console.log('refus noir : '+etat_noir.Joueur_noir.Refus);
        if (etat_noir.Joueur_noir.Abandon!='true') {
          if ((etat_noir.Joueur_noir.Partie_nulle!='true' || etat_blanc.Joueur_blanc.Partie_nulle!='true')){
            if(objet_json.cote!=1){
              //on relance les tests automatiques si ce n'est pas à notre tour de jouer
            relance = setTimeout(envoyerDonnees, 1000*Math.pow(2,num_test));
          }
        }
    }
    else if (objet_json.cote ==1){
      //on affiche le coup joué quand c'est à notre tour de jouer
      console.log('cote : '+objet_json.cote);
      alert(objet_json_modif[objet_json_modif.length-1]);
      alert('A votre tour!!!');
      console.log("l'adversaire noir a joué");
    }
    //la valeur dans le champ de saisie des données dans la page html devient 'null'.
    document.getElementById('test').value='';
    }else{
      alert("Error: returned status code " + req.status + " " + req.statusText);
    }
  }
}
  req.open("GET", "partie.php?donnees="+donneeClient+'&Abandon_blanc2='+Abb+'&Proposer_partie_nulle_blanc='+pnul+'&Rejeter_partie_nulle_blanc='+rej_pn, true);
  req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  req.send();
}
function verification(game){
  /*
    Fonction vérifiant si un coup a été joué.
  */
  // console.log(1*Math.pow(2,num_test));
  // console.log("verif : "+num_test);
  num_test+=1;
  test_ok=0;
  // console.log("historique : "+historique);
  // console.log("histo : "+JSON.stringify(game.histo));
  if (JSON.stringify(game.histo) == historique){
    console.log({ras:game.cote});

  }else{
    // console.log('TRUE');

    // console.log(game.histo[game.histo.length-1]);
    // console.log(game.histo.length);
    // console.log(JSON.parse(game.histo));
    historique= JSON.stringify(game.histo);
    // console.log("historique : "+historique.length);
    // console.log("histo : "+game.histo.length);
    // num_test=0;
  }

}
function validation(){
  /*
    Fonction permettant d'envoyer des données au serveur
  */
  if (test_ok==0){
//  clearTimeout(relance);
  num_test=0;
  console.log('manuel : '+num_test);
  test_ok =1;
  setTimeout(envoyerDonnees,5000);}
}

function verif_manuelle(){
  /*
    Fonction permettant au joueur de vérifier manuellement l'état d'avancement
    de la partie.
    Si une vérification manuelle est effectué, celle-ci remets alors à 0 le
    timer ("chrono") de la vérification automatique.
    Relance les vérifications automatiques 5 secondes après son utilisation.
  */
  if (cote==1){
  clearTimeout(relance);
}
  num_test=0;
  // console.log('manuel : '+num_test);
  test_ok =1;
  setTimeout(envoyerDonnees,5000);
}



var test_client= document.getElementById("debut");
test_client.addEventListener("click", function test(){
  //Active la vérification manuelle en cliquant sur le bouton 'Rafraichir'
  // console.log("test : "+test_ok);
  if (test_ok==0){
  verif_manuelle();}},false);

  //valeur du status pour l'"Abandon" de la partie du point de vue du joueur.
  //Ce status étant un booléen.
  var abandon = document.getElementById("fin_partie")

  //Permet de demander l'abandon de la partie en cliquant sur le bouton "Abandon"
  //initialisé à 'false' par défaut.
  var test_abandon_partie = document.getElementById("Ablanc").value;
  if (test_abandon_partie==""){

    document.getElementById("Ablanc").value='false';
  }

  abandon.addEventListener("click", function test_abandon(){
    //change la valeur du booléen attribué à l'Abandon en cliquant sur
    //le bouton abandon
    console.log('1er test : '+document.getElementById("Ablanc").value);
  if (document.getElementById("Ablanc").value=='false'){
    document.getElementById("Ablanc").value= 'true';
  }else{
    document.getElementById("Ablanc").value= 'false';
  }console.log('2nd test : '+document.getElementById("Ablanc").value);
  //
  //on envoi le changement au serveur
  envoyerDonnees();
  },false);



  //valeur du status de la "partie nulle" du point de vue du joueur.(booléen)
  var partie_nulle = document.getElementById('partie_nulle');

  //Permet de demander une partie nulle ou de l'accepter (si celle-ci à été proposé)
  // en cliquant sur le bouton "Partie nulle"
  //initialisé à 'false' par défaut.
  var test_pn = document.getElementById('PN').value;
  if (test_pn==''){
    test_pn = 'false';
  }

  partie_nulle.addEventListener("click", function test_abandon(){
    console.log('1er test : '+test_pn);
  if (document.getElementById('PN').value=='false'){
    document.getElementById('PN').value= 'true';
  }else{
    document.getElementById('PN').value= 'false';
  }console.log('2nd test : '+document.getElementById('PN').value);
  //on envoi le changement au serveur
  envoyerDonnees();
},false);

  //valeur du status de la "rejet partie nulle" du point de vue du joueur.(booléen)
  var rejet_pn = document.getElementById('Rejet');

  //Permet de refuser une partie nulle(si celle-ci à été proposé)
  // en cliquant sur le bouton "Rejet nulle"
  //initialisé à 'false' par défaut.
  var rpn = document.getElementById('RPN').value;
  if (rpn ==''){
     document.getElementById('RPN').value = 'false';
  }


  rejet_pn.addEventListener("click", function test_abandon(){

    console.log('1er test : '+document.getElementById('RPN').value);
  if ( document.getElementById('RPN').value=='false'){

     document.getElementById('RPN').value= 'true';
  }else{

     document.getElementById('RPN').value= 'false';
  }console.log('2nd test : '+document.getElementById('RPN').value);
  //on envoi le changement au serveur
  envoyerDonnees();
},false);



  envoyerDonnees();
