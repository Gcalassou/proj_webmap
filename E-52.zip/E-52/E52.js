
var chrono=0; // temps entre chaque test automatique
var test_ok=0; //variable permettant de bloquer l'envoi de données quand celui-ci est activé
var historique = "[]"; //variable permettant de stocker l'historique du client
var compteur=0; //variable temporelle
var data;

/*
  -----------------------------------------------------------------
  REQUETE AJAX AVEC LE SERVEUR
  -----------------------------------------------------------------
*/

function creerInstance(){
  //Fonction permettant de créer une requête xmlthttp à envoyer par la suite au serveur
  if(window.XMLHttpRequest){
    return new XMLHttpRequest();
  }else if(window.ActiveXObject){
    var names = [
      "Msxml2.XMLHTTP.6.0",
      "Msxml2.XMLHTTP.3.0",
      "Msxml2.XMLHTTP",
      "Microsoft.XMLHTTP"];
    for(var i in names){
      try{ return new ActiveXObject(names[i]); }
      catch(e){}
    }
    alert("Non supporte");
    return null; // non supporté
  }
};

function Abandon_adversaire(abandon_noir){
  /*
  Fonction testant si l'adversaire demande l'abandon de la partie
  */
  if (abandon_noir == 'true' ){
    //Si l'abandon est déclaré, on affiche un message pour afficher
    //notre vistoire
    alert('Vous avez gagné par abandon de votre adversaire!!')
  }
}

function egalite(egalite_noir, egalite_blanc, refus_noir){
  /*
    Fonction permettant de tester si :
      - l'adversaire demande une partie nulle
      - la demande de partie nulle a été acceptée
      - la demande de partie nulle a été rejetée
  */
  if (egalite_noir=='true'){
    //Si l'aversaire demande une partie nulle, la fonction nous renvoi
    //un message pour nous informer de cette demande
    alert("L'adversaire propose une partie nulle!!");
  }
  if (egalite_blanc =='true' && egalite_noir=='true'){
    // Vérifie si les deux joueurs ont acceptés la partie nulle
    //Renvoi un message pour signaler la fin de la partie
    alert('Partie nulle : Fin de la partie!!');
  }
  if (egalite_blanc =='true' && refus_noir=='true'){
    //Cas où  la demande de parite nulle a été rejeté
    // Renvoi un message pour informer le joueur
    alert("L'adversaire a refuser votre demande de finir une partie nulle!!");
    document.getElementById('PN').value= 'false';
  }
}


function envoyerDonnees (){
  /*
  Fonction permettant de faire une requête en AJAX au serveur
  Renvoi:
    -- etat de la partie (pion joué, cote, trait,  historique)
  */
  // "req" est égale à XMLHttpRequest si la création de la variable XTML est
  //validé par la fonction "creerInstance"
  var req =  creerInstance();
  var pion =document.getElementById('pion').value;
  var tour= document.getElementById('tour').value;
  var trait =document.getElementById('trait').value;
  var cote = document.getElementById('cote').value;

  req.onreadystatechange = function(){
  if(req.readyState == 4){
    if(req.status == 200){
      // On parse la donnée renvoyé par le serveur pour recuperer le contenu du tableau
      // retourne en json.
      donnee=JSON.parse(req.responseText);

      var coupAdverse=donnee.historique[donnee.historique.length-1];
      var i0=coupAdverse[0]; // abscisse depart
      var j0=coupAdverse[1]; // ordonnee depart
      var i1=coupAdverse[2]; // abscisse arrivee
      var j1=coupAdverse[3]; // ordonnee arrivee
      var natureCoup=donnee.nature
      var reponseAbandon=donnee.abandon;
      var reponsePartieNulle=donnee.partie_nulle;


      verification(donnee);

      chrono+=1;
      if(donnee.cote!=1){
      relance = setTimeout(envoyerDonnees, 1000*Math.pow(2,chrono));
    }else {
      alert(coupAdverse);
      alert('A votre tour!!!');
    }
    }else{
      alert("Error: returned status code " + req.status + " " + req.statusText);
    }
  }
}
  req.open("GET", "partie.php?pion="+pion+'&tour='+tour+'&trait='+trait+'&cote='+cote, true);
  req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  req.send();
}
function verification(game){
  /*
    Fonction vérifiant automatiquement suivant un intervalle de temps t
     (doublant à chaque test) si l'historique renvoyé par le serveur
     à changer par rapport à l'historique mise à jour à la dernière
     action effectuée.
  */
  chrono+=1;
  test_ok=0;
  //test entre l'ancien historique datant de la dernière action et celui
  //renvoyé par le serveur.
  //Renvoi:  --> ras : "cote" si rien n'a changé
  //         -->historique modifié par l'action effectuée
  if (JSON.stringify(game.histo) == historique){ //on converti l'objet json sous format string pour pouvoir le comparer

    console.log({ras:game.cote});//si rien ne se passe renvoi 'ras':cote

  }else{
    //s'il y a mouvement du joueur adverse, on garde le nouvel historique en memoire
    historique= JSON.stringify(game.histo);
  }

}


function verif_manuelle(){
  /*
    Fonction permettant au joueur de vérifier manuellement l'état d'avancement
    de la partie.
    Si une vérification manuelle est effectué, celle-ci remets alors à 0 le
    timer ("chrono") de la vérification automatique.
    Relance les vérifications automatiques 5 secondes après son utilisation.
  */
  clearTimeout(relance);
  chrono=0;
  test_ok =1;
  setTimeout(envoyerDonnees,5000);
}
//bouton permettant de rafraichir les résultat
var test_client= document.getElementById("boutton_rafraichir");
test_client.addEventListener("click", function test(){
  if (test_ok==0){
  verif_manuelle();}},false);

  //valeur du status pour l'"Abandon" de la partie du point de vue du joueur.
  //Ce status étant un booléen.
  var abandon = document.getElementById("fin_partie")
  //Permet de demander l'abandon de la partie en cliquant sur le bouton "Abandon"
  //initialisé à 'false' par défaut.
  var test_abandon = document.getElementById("Abandon_blanc").value;

  abandon.addEventListener("click", function test_abandon(){
    /*
    Effectue le changement de status lorsque l'on clique sur 'Abandon'.
    */
  if (document.getElementById("Abandon_blanc").value=='false'){
    document.getElementById("Abandon_blanc").value= 'true';
  }else{
    document.getElementById("Abandon_blanc").value= 'false';
  }},false);

  //valeur du status de la "partie nulle" du point de vue du joueur.(booléen)
  var partie_nulle = document.getElementById('partie_nulle');
  //Permet de demander une partie nulle ou de l'accepter (si celle-ci à été proposé)
  // en cliquant sur le bouton "Partie nulle"
  //initialisé à 'false' par défaut.
  var test_partie_nulle = document.getElementById('PN').value;
  if (test_partie_nulle==''){
    test_partie_nulle = 'false';
  }
  partie_nulle.addEventListener("click", function test_abandon(){

  if (document.getElementById('PN').value=='false'){
    document.getElementById('PN').value= 'true';
  }else{
    document.getElementById('PN').value= 'false';
  }},false);

  //valeur du status de la "rejet partie nulle" du point de vue du joueur.(booléen)
  var rejet_pn = document.getElementById('Rejet');
  //Permet de refuser une partie nulle(si celle-ci à été proposé)
  // en cliquant sur le bouton "Rejet nulle"
  //initialisé à 'false' par défaut.
  var rejet_partie_nulle = document.getElementById('RPN').value;
  if (rejet_partie_nulle ==''){
     document.getElementById('RPN').value = 'false';
  }
  rejet_pn.addEventListener("click", function test_abandon(){

  if ( document.getElementById('RPN').value=='false'){
     document.getElementById('RPN').value= 'true';
  }else{
     document.getElementById('RPN').value= 'false';
  }},false);


  envoyerDonnees();
